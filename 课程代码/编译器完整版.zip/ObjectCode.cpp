#include"head.h"

void ObjectCode::ObjCode() {
    Object obj;
    Object_list.push_back(obj);
    obj_now = --Object_list.end();
    (*obj_now).type = '0';
    (*obj_now).lab = 0;
    UpdateSymbol();//���·��ű�����ϵͳ�����м��������
    GetHead();//Ŀ�����ͷ������(�����ݶ�)
    for (qua_blo = Block_list.begin();qua_blo != Block_list.end();qua_blo++)
    {
        //blo=blo->next;
        for (qua = (*qua_blo).begin();qua != (*qua_blo).end();qua++) {
            //qua = blo->qua_block;
            GetObjCode();//����Ŀ�����
        }
    }
    GetTail();//Ŀ�����β������
    CoutObj();//���Ŀ�����
}

void ObjectCode::UpdateSymbol() {//���·��ű�����ϵͳ�����м��������
    for (list<list<Quaternary>>::iterator b = Block_list.begin();b != Block_list.end();b++)
    {
        for (list<Quaternary>::iterator q = (*b).begin();q != (*b).end();q++)
        {
            for (int i = 0;i < 3;i++)
            {//
                if ((*((*q).operand[i].tpToken)).token == "99")
                {
                    find_num = (*(*q).operand[i].tpToken).line;
                    if (!SystemExist())
                    {
                        SYNBL id_new;
                        stringstream s;
                        string str;
                        s << find_num;
                        s >> str;
                        id_new.name = "t" + str;
                        id_new.cat = 's';
                        SYNBL_list.push_back(id_new);
                    }
                }
            }
        }
    }
}

void ObjectCode::CoutObj() {//���Ŀ�����

    FILE* fp;
    fp = fopen("code.ASM", "w");
    for (list<Object>::iterator o = Object_list.begin();o != Object_list.end();o++)
    {
        if ((*o).type == '0')
        {
            cout << (*o).code << endl;
            char* c = (char*)(*o).code.c_str();	//��stringת��Ϊchar*��д���ļ� 
            fprintf(fp, c);
            fprintf(fp, "\n");
        }
    }
    fclose(fp);
}

int ObjectCode::SystemExist() {//���ҷ��ű����Ƿ��б�����м����
    string st;
    stringstream s;
    s << find_num;
    s >> st;
    string name = "t" + st;
    //if (id == SYNBL_list.end()) { return 0; }
    list<SYNBL>::iterator it;
    for (it = SYNBL_list.begin(); it != SYNBL_list.end(); it++)
    {
        if ((*it).name == name)
            return 1;
    }
    return 0;
}

void ObjectCode::GetHead() {//����ͷ����������
    string s = "DSEG SEGMENT";
    (*obj_now).code = s;
    AddObject();
    for (list<SYNBL>::iterator in = SYNBL_list.begin();in != SYNBL_list.end();in++)
    {
        string st = "";
        st = (*in).name;
        s = st + " DW 0";
        //ConvertStoC(s,obj_now->code);
        obj_now->code = s;
        AddObject();
    }
    s = "DSEG ENDS";
    //ConvertStoC(s,obj_now->code);
    obj_now->code = s;
    AddObject();//����obj���
    s = "CSEG SEGMENT";
    //ConvertStoC(s,obj_now->code);
    obj_now->code = s;
    AddObject();
    s = "ASSUME CS:CSEG,DS:DSEG";
    //ConvertStoC(s,obj_now->code);
    obj_now->code = s;
    AddObject();
    s = "START:MOV AX,DSEG";
    //ConvertStoC(s,obj_now->code);
    obj_now->code = s;
    AddObject();
    s = "MOV DS,AX";
    //ConvertStoC(s,obj_now->code);
    obj_now->code = s;
    AddObject();
}

void ObjectCode::GetTail() {//����β��������־
    lab++;
    string slab = "";
    //��ȡ��ַ
    ss << lab;
    ss >> slab;
    string s1 = "LAB" + slab + ":";
    string s = s1 + "MOV AH,4CH";
    //ConvertStoC(s,obj_now->code);
    (*obj_now).code = s;
    AddObject();//����obj���
    s = "MOV AL,0";
    //ConvertStoC(s,obj_now->code);
    (*obj_now).code = s;
    AddObject();
    s = "INT 21H";
    //ConvertStoC(s,obj_now->code);
    (*obj_now).code = s;
    AddObject();
    s = "CSEG ENDS";
    //ConvertStoC(s,obj_now->code);
    (*obj_now).code = s;
    AddObject();
    s = "END START";
    //ConvertStoC(s,obj_now->code);
    (*obj_now).code = s;
    AddObject();
}

void ObjectCode::AddObject() {//����obj���
    Object obj;
    Object_list.push_back(obj);
    obj_now = --Object_list.end();
    (*obj_now).type = '0';
    (*obj_now).lab = 0;
}

void ObjectCode::Judge(string& st) {//��ȡ���������ͣ��浽numType
    if ((*(*num).tpToken).token == "ZT") {//int
        stringstream s;
        s << (*(*num).tpToken).tpI->numi;
        s >> st;
    }
    else if ((*(*num).tpToken).token == "RT") {//real
        stringstream s;
        s << (*(*num).tpToken).tpR->numf;
        s >> st;
    }
    else if ((*(*num).tpToken).token == "CT") {//char
        st = (*(*num).tpToken).tpC->numc;
    }
    else if ((*(*num).tpToken).token == "IT") {//identifier
        st = (*(*(*num).tpToken).tpIT).name;
    }
    else if ((*(*num).tpToken).token == "99") {//system��ti
        string sm;
        stringstream s;
        s << (*(*num).tpToken).line;
        s >> sm;
        st = "t" + sm;
    }
}

void ObjectCode::GetObjCode() {//��ȡĿ�����

    if ((*(*qua).Operator) == "=") {
        MOV_BX_A();
        MOV_C_BX();
    }
    else if ((*(*qua).Operator) == "++")
    {
        MOV_BX_A();
        MOV_C_BX();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "INC BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_A_BX();
    }
    else if ((*(*qua).Operator) == "--")
    {
        MOV_BX_A();
        MOV_C_BX();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "DEC BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_A_BX();
    }
    else if ((*(*qua).Operator) == "!")
    {
        MOV_BX_A();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "NEG BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_C_BX();
    }
    else if ((*(*qua).Operator) == "~")
    {
        MOV_BX_A();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "NOT BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_C_BX();
    }
    else if ((*(*qua).Operator) == "inc")
    {
        MOV_BX_A();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "INC BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_A_BX();
        MOV_C_BX();
    }
    else if ((*(*qua).Operator) == "dec")
    {
        MOV_BX_A();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "DEC BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_A_BX();
        MOV_C_BX();
    }
    else if ((*(*qua).Operator) == "+")
    {
        MOV_AX_A();
        MOV_BX_B();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "ADD AX,BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_C_AX();
    }
    else if ((*(*qua).Operator) == "-")
    {
        MOV_AX_A();
        MOV_BX_B();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "SUB AX,BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_C_AX();
    }
    else if ((*(*qua).Operator) == "*")
    {
        MOV_AX_A();
        MOV_BX_B();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "IMUL BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_C_AX();
    }
    else if ((*(*qua).Operator) == "/")
    {
        MOV_AX_A();
        MOV_BX_B();
        MOV_DX_ZERO();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "IDIV BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_C_AX();
    }
    else if ((*(*qua).Operator) == "%")
    {
        MOV_AX_A();
        MOV_BX_B();
        MOV_DX_ZERO();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "IDIV BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_C_DX();
    }
    else if ((*(*qua).Operator) == ">")
    {
        MOV_AX_A();
        MOV_BX_B();
        MOV_CX_ONE();
        CMP_AX_BX();
        lab++;
        string slab;
        string slab_jmp;
        int lab_jmp = lab + 2;
        stringstream ss;
        ss << lab;
        ss >> slab;
 		slab_jmp=to_string(lab_jmp);
        ss << lab_jmp;
        ss >> slab_jmp;

        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JG LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_CX_ZERO();
        MOV_C_CX();
    }
    else if ((*(*qua).Operator) == ">=")
    {
        MOV_AX_A();
        MOV_BX_B();
        MOV_CX_ONE();
        CMP_AX_BX();
        lab++;
        string slab;
        string slab_jmp;
        int lab_jmp = lab + 2;
        //��ȡ��ַ
        stringstream ss;
        ss << lab;
        ss >> slab;
        //��ȡ��ת��ַ
        slab_jmp=to_string(lab_jmp);
//        ss << lab_jmp;
//        ss >> slab_jmp;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JGE LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_CX_ZERO();
        MOV_C_CX();
    }
    else if ((*(*qua).Operator) == "<")
    {
        MOV_AX_A();
        MOV_BX_B();
        MOV_CX_ONE();
        CMP_AX_BX();
        lab++;
        string slab;
        string slab_jmp;
        int lab_jmp = lab + 2;
        //��ȡ��ַ
        stringstream ss;
        ss << lab;
        ss >> slab;
        //��ȡ��ת��ַ
        slab_jmp=to_string(lab_jmp);
//        ss << lab_jmp;
//        ss >> slab_jmp;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JL LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_CX_ZERO();
        MOV_C_CX();
    }
    else if ((*(*qua).Operator) == "<=")
    {
        MOV_AX_A();
        MOV_BX_B();
        MOV_CX_ONE();
        CMP_AX_BX();
        lab++;
        string slab;
        string slab_jmp;
        int lab_jmp = lab + 2;
        stringstream ss;
        ss << lab;
        ss >> slab;
        //��ȡ��ת��ַ
        slab_jmp=to_string(lab_jmp);
        ss << lab_jmp;
        ss >> slab_jmp;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JLE LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_CX_ZERO();
        MOV_C_CX();
    }
    else if ((*(*qua).Operator) == "==")
    {
        MOV_AX_A();
        MOV_BX_B();
        MOV_CX_ONE();
        CMP_AX_BX();
        lab++;
        string slab;
        string slab_jmp;
        int lab_jmp = lab + 2;
        stringstream ss;
        ss << lab;
        ss >> slab;
        //��ȡ��ת��ַ
        slab_jmp=to_string(lab_jmp);
//        ss << lab_jmp;
//        ss >> slab_jmp;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JE LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_CX_ZERO();
        MOV_C_CX();
    }
    else if ((*(*qua).Operator) == "!=")
    {
        MOV_AX_A();
        MOV_BX_B();
        MOV_CX_ONE();
        CMP_AX_BX();
        lab++;
        string slab;
        string slab_jmp;
        int lab_jmp = lab + 2;
        stringstream ss;
        ss << lab;
        ss >> slab;
        //��ȡ��ת��ַ
        slab_jmp=to_string(lab_jmp);
//        ss << lab_jmp;
//        ss >> slab_jmp;

        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JNE LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��
        MOV_CX_ZERO();
        MOV_C_CX();
    }
    else if ((*(*qua).Operator) == "&&")
    {
        MOV_AX_A();
        MOV_CX_ZERO();
        CMP_AX_ZERO();
        stringstream ss;
        lab++;
        string slab;
        string slab_jmp;
        int lab_jmp = lab + 5;
        //ConvertItoS(lab,slab);//��ȡ��ַ

        ss << lab;
        ss >> slab;
        //ConvertItoS(lab_jmp,slab_jmp);//��ȡ��ת��ַ
        slab_jmp=to_string(lab_jmp);
//        ss << lab_jmp;
//        ss >> slab_jmp;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JZ LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��

        MOV_BX_B();
        CMP_BX_ZERO();

        lab++;
        slab = "";
        slab_jmp = "";
        lab_jmp = lab + 2;
        //ConvertItoS(lab,slab);//��ȡ��ַ
        slab=to_string(lab);

        //ConvertItoS(lab_jmp,slab_jmp);//��ȡ��ת��ַ
        slab_jmp=to_string(lab_jmp);

        s = "";
        s1 = "LAB" + slab + ":";
        s2 = "JZ LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��

        MOV_CX_ONE();
        MOV_C_CX();
    }
    else if ((*(*qua).Operator) == "||")
    {
        MOV_AX_A();
        MOV_CX_ONE();
        CMP_AX_ZERO();
        stringstream ss;
        lab++;
        string slab;
        string slab_jmp;
        int lab_jmp = lab + 5;
        ss << lab;
        ss >> slab;
        slab_jmp=to_string(lab_jmp);
//        ss << lab_jmp;
//        ss >> slab_jmp;
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JNZ LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��

        MOV_BX_B();
        CMP_BX_ZERO();
        lab++;
        slab = "";
        slab_jmp = "";
        lab_jmp = lab + 2;
        slab=to_string(lab);
//        ss << lab;
//        ss >> slab;
		slab_jmp=to_string(lab_jmp);
//        ss << lab_jmp;
//        ss >> slab_jmp;
        s = "";
        s1 = "LAB" + slab + ":";
        s2 = "JNZ LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��

        MOV_CX_ZERO();
        MOV_C_CX();
    }
    else if (*(*qua).Operator == "&")
    {
        MOV_AX_A();
        MOV_BX_B();
        stringstream ss;
        lab++;
        string slab;
        ss << lab;
        ss >> slab;//��ȡ��ַ
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "AND AX,BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��

        MOV_C_AX();
    }
    else if (*(*qua).Operator == "|")
    {
        MOV_AX_A();
        MOV_BX_B();
        stringstream ss;
        lab++;
        string slab;
        ss << lab;
        ss >> slab;//��ȡ��ַ
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "OR AX,BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��

        MOV_C_AX();
    }
    else if (*(*qua).Operator == "^")
    {
        MOV_AX_A();
        MOV_BX_B();
        stringstream ss;
        lab++;
        string slab;
        ss << lab;
        ss >> slab;//��ȡ��ַ
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "XOR AX,BX";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��

        MOV_C_AX();
    }
    else if (*(*qua).Operator == ">>")
    {
        MOV_AX_A();
        MOV_CX_B();
        stringstream ss;
        lab++;
        string slab;
        ss << lab;
        ss >> slab;//��ȡ��ַ
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "SAR AX,CL";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��

        MOV_C_AX();
    }
    else if (*(*qua).Operator == "<<")
    {
        MOV_AX_A();
        MOV_CX_B();
        stringstream ss;
        lab++;
        string slab;
        ss << lab;
        ss >> slab;//��ȡ��ַ
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "SAL AX,CL";
        s = s1 + s2;
        (*obj_now).lab = lab;
        (*obj_now).code = s;
        AddObject();//�����½��

        MOV_C_AX();
    }
    else if (*(*qua).Operator == "if")
    {
        MOV_BX_A();
        CMP_BX_ZERO();

        lab++;
        (*obj_now).lab = lab;
        (*obj_now).type = 'i';//if��תλ�ô�����
        AddObject();//�����½��

    }
    else if (*(*qua).Operator == "el")
    {
        lab++;
        (*obj_now).lab = lab;
        (*obj_now).type = 'e';//else��תλ�ô�����
        AddObject();//�����½��

        type_find = 'i';
        int lab_jmp = lab + 1;
        string slab_jmp;
        stringstream ss;
        ss << lab_jmp;
        ss >> slab_jmp;//��ȡifҪ��ת�ĵ�ַ
        Find_obj();//�ҵ�if

        string slab;
        slab = to_string((*obj_find).lab);

        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JZ LAB" + slab_jmp;
        s = s1 + s2;

        (*obj_find).type = '0';//ȡ�����
        (*obj_find).code = s;;
    }
    else if (*(*qua).Operator == "ie")
    {
        type_find = 'e';
        int lab_jmp = lab + 1;
        string slab_jmp;
        stringstream ss;
        ss << lab_jmp;
        ss >> slab_jmp;//��ȡelseҪ��ת�ĵ�ַ
        Find_obj();//�ҵ�else

        string slab;
        slab = to_string((*obj_find).lab);//��ȡelse���ĵ�ַ

        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JMP LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_find).type = '0';//ȡ�����
        (*obj_find).code = s;
    }
    else if (*(*qua).Operator == "wh")
    {
        (*obj_now).lab = lab + 1;
        (*obj_now).type = 'w';//while��ʼλ�ã���¼�����ǲ���������
        AddObject();//�����½��
    }
    else if (*(*qua).Operator == "do")
    {
        MOV_BX_A();
        CMP_BX_ZERO();
        lab++;
        (*obj_now).lab = lab;
        (*obj_now).type = 'd';//do��תλ�ô�����
        AddObject();//�����½��
    }
    else if (*(*qua).Operator == "we")
    {
        //����do���
        type_find = 'd';
        int lab_jmp = lab + 2;
        string slab_jmp;
        stringstream ss;
        ss << lab_jmp;
        ss >> slab_jmp;//��ȡdoҪ��ת�ĵ�ַ
        Find_obj();//�ҵ�do

        string slab;
        slab = to_string((*obj_find).lab);//��ȡdo���ĵ�ַ
        string s = "";
        string s1 = "LAB" + slab + ":";
        string s2 = "JZ LAB" + slab_jmp;
        s = s1 + s2;


        (*obj_find).type = '0';//ȡ�����
        (*obj_find).code = s;

        lab++;
        (*obj_now).lab = lab;
        (*obj_now).type = '0';
        slab = "";
        slab = to_string(lab);

        type_find = 'w';
        Find_obj();//�ҵ�while
        (*obj_find).type = '0';//ȡ�����
        slab_jmp = "";
        slab_jmp = to_string((*obj_find).lab);//��ȡwhile���ĵ�ַ

        s = "";
        s1 = "LAB" + slab + ":";
        s2 = "JMP LAB" + slab_jmp;
        s = s1 + s2;
        (*obj_now).code = s;
        AddObject();//�����½��
    }
    else if (*(*qua).Operator == "co")
        //(strcmp(qua->Operator,"co")==0)
    {
        MOV_AX_A();
        lab++;
        string slab;
        stringstream ss;
        ss << lab;
        ss >> slab;
        string s1 = "LAB" + slab + ":";
        string s = s1 + "AAA";
        (*obj_now).code = s;
        AddObject();

        lab++;
        slab = to_string(lab);
        s1 = "LAB" + slab + ":";
        s = s1 + "OR AX,3030H";
        (*obj_now).code = s;
        AddObject();

        lab++;
        slab = to_string(lab);
        s1 = "LAB" + slab + ":";
        s = s1 + "MOV BX,AX";
        (*obj_now).code = s;
        AddObject();

        lab++;
        slab = to_string(lab);
        s = "";
        s1 = "LAB" + slab + ":";
        s = s1 + "MOV DL,BH";
        (*obj_now).code = s;
        AddObject();//�����½��

        lab++;
        slab = to_string(lab);
        s1 = "LAB" + slab + ":";
        s = s1 + "MOV AH,02H";
        (*obj_now).code = s;
        AddObject();

        lab++;
        slab = to_string(lab);
        s1 = "LAB" + slab + ":";
        s = s1 + "INT 21H";
        (*obj_now).code = s;
        AddObject();

        lab++;
        slab = to_string(lab);
        s1 = "LAB" + slab + ":";
        s = s1 + "MOV DL,BL";
        (*obj_now).code = s;
        AddObject();

        lab++;
        slab = to_string(lab);
        s1 = "LAB" + slab + ":";
        s = s1 + "INT 21H";
        (*obj_now).code = s;
        AddObject();

        lab++;
        slab = to_string(lab);
        s1 = "LAB" + slab + ":";
        s = s1 + "MOV DL,10";
        (*obj_now).code = s;
        AddObject();

        lab++;
        slab = to_string(lab);
        s1 = "LAB" + slab + ":";
        s = s1 + "INT 21H";
        (*obj_now).code = s;
        AddObject();
    }
}

int ObjectCode::Find_obj() {//�Ӻ���ǰѰ����Ӧ���͵��׸�Ŀ��������
    list<Object>::iterator ob = obj_now;

    for (;ob != Object_list.begin(); ob--)
    {
        if ((*ob).type == type_find)
        {
            obj_find = ob;
            return 1;
        }
    }
    if ((*ob).type = type_find)
    {
        obj_find = ob;
        return 1;
    }
    return 0;
}

int ObjectCode::Find_obj_head() {//��ǰ���Ѱ����Ӧ���͵��׸�Ŀ��������
    list<Object>::iterator ob;
    ob = obj;
    for (;ob != Object_list.end(); ob++)
    {
        if ((*ob).type == type_find)
        {
            obj_find = ob;
            return 1;
        }
    }
    if ((*ob).type == type_find)
    {
        obj_find = ob;
        return 1;
    }
    return 0;
}

void ObjectCode::MOV_BX_A() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "MOV BX,";
    string s3 = "";
    num = (*qua).operand.begin();
    Judge(s3);
    s = s1 + s2 + s3;
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_BX_B() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "MOV BX,";
    string s3 = "";
    (*num) = (*qua).operand[1];
    Judge(s3);
    s = s1 + s2 + s3;
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_CX_B() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "MOV CX,";
    string s3 = "";
    (*num) = (*qua).operand[1];
    Judge(s3);
    s = s1 + s2 + s3;
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_C_BX() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "";
    (*num) = (*qua).operand[2];
    Judge(s2);
    s = s1 + "MOV " + s2 + ",BX";
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_C_CX() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "";
    (*num) = (*qua).operand[2];
    Judge(s2);
    s = s1 + "MOV " + s2 + ",CX";
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_A_BX() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "";
    (*num) = (*qua).operand[0];
    Judge(s2);
    s = s1 + "MOV " + s2 + ",BX";
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_AX_A() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "MOV AX,";
    string s3 = "";
    num = (*qua).operand.begin();
    Judge(s3);
    s = s1 + s2 + s3;
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_C_AX() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "";
    (*num) = (*qua).operand[2];
    Judge(s2);
    s = s1 + "MOV " + s2 + ",AX";
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_DX_ZERO() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "MOV DX,0";
    s = s1 + s2;
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_C_DX() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "";
    (*num) = (*qua).operand[2];
    Judge(s2);
    s = s1 + "MOV " + s2 + ",DX";
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_CX_ONE() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "MOV CX,1";
    s = s1 + s2;
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::MOV_CX_ZERO() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "MOV CX,0";
    s = s1 + s2;
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::CMP_AX_BX() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "CMP AX,BX";
    s = s1 + s2;
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::CMP_AX_ZERO() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "CMP AX,0";
    s = s1 + s2;
    (*obj_now).lab = lab;
    (*obj_now).code = s;
    AddObject();//�����½��
}

void ObjectCode::CMP_BX_ZERO() {
    lab++;
    string slab;
    stringstream ss;
    ss << lab;
    ss >> slab;
    string s = "";
    string s1 = "LAB" + slab + ":";
    string s2 = "CMP BX,0";
    s = s1 + s2;
    (*obj_now).lab = lab;
    //ConvertStoC(s, obj_now->code);
    obj_now->code = s;
    (*obj_now).code = s;
    AddObject();//�����½��
}
